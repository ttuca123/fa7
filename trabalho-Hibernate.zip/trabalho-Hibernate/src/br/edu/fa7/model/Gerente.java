/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.edu.fa7.model;

import javax.persistence.Entity;

@Entity
public class Gerente extends Funcionario {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5366628231248555232L;

	public Gerente() {

	}

}