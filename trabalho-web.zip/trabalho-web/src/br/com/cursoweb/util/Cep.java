package br.com.cursoweb.util;

/**
 * 
 * @author Artur
 *
 */
public class Cep {

	private String regiao;
	private String sufixo;

	public Cep() {

	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	public String getSufixo() {
		return sufixo;
	}

	public void setSufixo(String sufixo) {
		this.sufixo = sufixo;
	}

}
